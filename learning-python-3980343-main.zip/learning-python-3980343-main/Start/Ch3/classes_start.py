# LinkedIn Learning Python course by Joe Marini
# Example file for working with classes
#

