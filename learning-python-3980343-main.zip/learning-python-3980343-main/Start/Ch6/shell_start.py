#
# Example file for working with filesystem shell methods
# LinkedIn Learning Python course by Joe Marini
#


# make a duplicate of an existing file

    # get the path to the file in the current directory

        
    # # let's make a backup copy by appending "bak" to the name

    # # now use the shell to make a copy of the file


    # # rename the original file

    
    # now put things into a ZIP archive


    # more fine-grained control over ZIP files
      