# LinkedIn Learning Python course by Joe Marini
# Example file for working with functions


# define a basic function
print("hello world!")
name = input("What is your name? ")
print("Nice to meet you,", name)

# function that takes parameters


# function that returns a value


# function with default value for an parameter


# function with variable number of parameters
