# LinkedIn Learning Python course by Joe Marini
# Example file for working with loops


x = 0

# define a while loop


# define a for loop


# use a for loop over a collection


# use the break and continue statements


# using the enumerate() function to get an index and an item
